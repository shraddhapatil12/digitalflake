import React from 'react';
import './login.css';
import logo from '../../../public/logo.png';

const Login = () => {
    return (
        <div className='formContainer'>
            <div className='logo'>
                <img src={logo} alt="logo" />
                <p id='welcomePara'>Welcome to Digitalflake admin</p>
            </div>
            <form className='form'>
                <div className='grp'>
                <div className="form-group">
                    <label htmlFor="email">Email-id</label>
                    <input type="email" id="email" name="email" placeholder="Enter your email" />
                </div>
                <div className="form-group">
                    <label htmlFor="password">Password</label>
                    <input type="password" id="password" name="password" placeholder="Enter your password" />
                </div>
                </div>
                <a href='#' id='forgotLink'>Forgot Password?</a>
                <button type="submit">Log In</button>
            </form>
        </div>
    );
};

export default Login;
