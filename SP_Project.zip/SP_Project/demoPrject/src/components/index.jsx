import React from 'react'
import Login from './login/Login'
import './index.css'

const IndexFile = () => {
    return (
        <div className='mainContainer'>
            <Login />
        </div>
    )
}

export default IndexFile

