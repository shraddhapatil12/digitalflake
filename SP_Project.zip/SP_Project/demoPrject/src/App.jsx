import React from 'react'
import IndexFile from './components'

const App = () => {
  return (
    <>
      <IndexFile />
    </>
  )
}

export default App